package com.example.inshaallah.ui.slideshow;

import android.app.Fragment;

public class developerFragment extends Fragment {
}
