package com.example.inshaallah.ui.home;

import android.app.Fragment;

public class homeSecondFragment extends Fragment {
}
